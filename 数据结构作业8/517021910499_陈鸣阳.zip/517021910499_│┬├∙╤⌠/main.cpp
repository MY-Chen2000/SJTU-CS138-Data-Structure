#include <iostream>
#include "hash.h"
#include "string.h"
#include<string>
#include<sstream>


using namespace std;

int main()
{

//   test("hash1.txt",0,1,1);
//   testremove("hash1.txt",0,1,1);
//
//   test("hash1.txt",0,1,2);
//   testremove("hash1.txt",0,1,2);
//
//   test("hash1.txt",0,1,3);
//   testremove("hash1.txt",0,1,3);
//
//   test("hash1.txt",0,1,4);
//   testremove("hash1.txt",0,1,4);
//
//   test("hash1.txt",0,2,1);
//   testremove("hash1.txt",0,2,1);
//
//   test("hash1.txt",0,2,2);
//   testremove("hash1.txt",0,2,2);
//
//   test("hash1.txt",0,2,3);
//   testremove("hash1.txt",0,2,3);
//
//   test("hash1.txt",0,2,4);
//   testremove("hash1.txt",0,2,4);

//cout<<"hash2.txt:"<<endl;
//      test("hash2.txt",0,1,1);
//   testremove("hash2.txt",0,1,1);
//
//   test("hash2.txt",0,1,2);
//   testremove("hash2.txt",0,1,2);
//
//   test("hash2.txt",0,1,3);
//   testremove("hash2.txt",0,1,3);
//
//   test("hash2.txt",0,1,4);
//   testremove("hash2.txt",0,1,4);
//
//   test("hash2.txt",0,2,1);
//   testremove("hash2.txt",0,2,1);
//
//   test("hash2.txt",0,2,2);
//   testremove("hash2.txt",0,2,2);
//
//   test("hash2.txt",0,2,3);
//   testremove("hash2.txt",0,2,3);
//
//   test("hash2.txt",0,2,4);
//   testremove("hash2.txt",0,2,4);

//cout<<"hash3.txt:"<<endl;
//      test("hash3.txt",1,1,1);
//   testremove("hash3.txt",1,1,1);
//
//   test("hash3.txt",1,1,2);
//   testremove("hash3.txt",1,1,2);
//
//   test("hash3.txt",1,1,3);
//   testremove("hash3.txt",1,1,3);
//
//   test("hash3.txt",1,1,4);
//   testremove("hash3.txt",1,1,4);
//
//   test("hash3.txt",1,2,1);
//   testremove("hash3.txt",1,2,1);
//
//   test("hash3.txt",1,2,2);
//   testremove("hash3.txt",1,2,2);
//
//   test("hash3.txt",1,2,3);
//   testremove("hash3.txt",1,2,3);
//
//   test("hash3.txt",1,2,4);
//   testremove("hash3.txt",1,2,4);

cout<<"hash4.txt:"<<endl;
      test("hash4.txt",1,1,1);
   testremove("hash4.txt",1,1,1);

   test("hash4.txt",1,1,2);
   testremove("hash4.txt",1,1,2);

   test("hash4.txt",1,1,3);
   testremove("hash4.txt",1,1,3);

   test("hash4.txt",1,1,4);
   testremove("hash4.txt",1,1,4);

   test("hash4.txt",1,2,1);
   testremove("hash4.txt",1,2,1);

   test("hash4.txt",1,2,2);
   testremove("hash4.txt",1,2,2);

   test("hash4.txt",1,2,3);
   testremove("hash4.txt",1,2,3);

   test("hash4.txt",1,2,4);
   testremove("hash4.txt",1,2,4);


    return 0;
}
