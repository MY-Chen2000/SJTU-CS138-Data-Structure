#include <iostream>
#include"halfman.h"


using namespace std;

int main()
{


         hftree<char> tree("test3.txt");
         tree.getcode();








    return 0;
}
